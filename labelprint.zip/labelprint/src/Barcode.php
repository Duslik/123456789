<?php

/**
 * ---------------------------------------------------------------------
 *
 * Labelprint - GLPI plugin printing 43x25 mm inventory labels.
 *
 * ---------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

namespace GlpiPlugin\Labelprint;

/**
 * Code 128 encoder (subsets B/C with optimal switching) and SVG renderer.
 *
 * Width table source: ISO/IEC 15417 patterns, as published on the
 * "Code 128" Wikipedia page (values 0..105 are 11-module symbols,
 * value 106 is the 13-module stop pattern).
 */
final class Barcode
{
    public const START_A = 103;
    public const START_B = 104;
    public const START_C = 105;
    public const STOP    = 106;

    /** Code set switches. */
    private const CODE_C_IN_AB = 99;
    private const CODE_B_IN_C  = 100;
    private const CODE_A_IN_C  = 101;
    private const CODE_A_IN_B  = 101;
    private const CODE_B_IN_A  = 100;

    /**
     * Bar/space widths per symbol value, in modules.
     * Elements alternate bar/space starting with a bar.
     *
     * @var array<int, string>
     */
    private const WIDTHES = [
        0 => '212222', 1 => '222122', 2 => '222221', 3 => '121223',
        4 => '121322', 5 => '131222', 6 => '122213', 7 => '122312',
        8 => '132212', 9 => '221213', 10 => '221312', 11 => '231212',
        12 => '112232', 13 => '122132', 14 => '122231', 15 => '113222',
        16 => '123122', 17 => '123221', 18 => '223211', 19 => '221132',
        20 => '221231', 21 => '213212', 22 => '223112', 23 => '312131',
        24 => '311222', 25 => '321122', 26 => '321221', 27 => '312212',
        28 => '322112', 29 => '322211', 30 => '212123', 31 => '212321',
        32 => '232121', 33 => '111323', 34 => '131123', 35 => '131321',
        36 => '112313', 37 => '132113', 38 => '132311', 39 => '211313',
        40 => '231113', 41 => '231311', 42 => '112133', 43 => '112331',
        44 => '132131', 45 => '113123', 46 => '113321', 47 => '133121',
        48 => '313121', 49 => '211331', 50 => '231131', 51 => '213113',
        52 => '213311', 53 => '213131', 54 => '311123', 55 => '311321',
        56 => '331121', 57 => '312113', 58 => '312311', 59 => '332111',
        60 => '314111', 61 => '221411', 62 => '431111', 63 => '111224',
        64 => '111422', 65 => '121124', 66 => '121421', 67 => '141122',
        68 => '141221', 69 => '112214', 70 => '112412', 71 => '122114',
        72 => '122411', 73 => '142112', 74 => '142211', 75 => '241211',
        76 => '221114', 77 => '413111', 78 => '241112', 79 => '134111',
        80 => '111242', 81 => '121142', 82 => '121241', 83 => '114212',
        84 => '124112', 85 => '124211', 86 => '411212', 87 => '421112',
        88 => '421211', 89 => '212141', 90 => '214121', 91 => '412121',
        92 => '111143', 93 => '111341', 94 => '131141', 95 => '114113',
        96 => '114311', 97 => '411113', 98 => '411311', 99 => '113141',
        100 => '114131', 101 => '311141', 102 => '411131',
        103 => '211412', // Start A
        104 => '211214', // Start B
        105 => '211232', // Start C
        106 => '2331112', // Stop (13 modules)
    ];

    /** Quiet zone width in modules on each side (10x module, per spec). */
    private const QUIET_ZONE = 10;

    /**
     * Full symbol width table (exposed for tests).
     *
     * @return array<int, string>
     */
    public static function widthTable(): array
    {
        return self::WIDTHES;
    }

    /**
     * Encode text into a list of Code 128 symbol values
     * (start + data + checksum + stop).
     *
     * Only printable ASCII (32..126) is supported: subsets B and C cover it
     * completely, and inventory numbers are expected to be ASCII.
     *
     * @return list<int>
     * @throws \InvalidArgumentException
     */
    public static function encode(string $text): array
    {
        $length = strlen($text);
        if ($length === 0) {
            throw new \InvalidArgumentException('Cannot encode an empty string.');
        }
        for ($i = 0; $i < $length; $i++) {
            $ord = ord($text[$i]);
            if ($ord < 32 || $ord > 126) {
                throw new \InvalidArgumentException(sprintf(
                    'Character "%s" (position %d) cannot be encoded in Code 128 subsets B/C.',
                    $text[$i],
                    $i
                ));
            }
        }

        [$dpB, $dpC] = self::plan($text);

        $start = $dpC[0] <= $dpB[0] ? self::START_C : self::START_B;
        $values = [$start];

        $pos = 0;
        $subset = $start === self::START_C ? 'C' : 'B';
        while ($pos < $length) {
            $two_digits = $pos + 1 < $length
                && self::isDigit($text[$pos])
                && self::isDigit($text[$pos + 1]);

            if ($subset === 'B') {
                if ($two_digits && $dpB[$pos] === 1 + $dpC[$pos + 2]) {
                    $values[] = self::CODE_C_IN_AB;
                    $subset = 'C';
                    continue;
                }
                $values[] = ord($text[$pos]) - 32;
                $pos++;
            } else {
                if ($two_digits && $dpC[$pos] === 1 + $dpC[$pos + 2]) {
                    $values[] = ((int) $text[$pos]) * 10 + (int) $text[$pos + 1];
                    $pos += 2;
                } else {
                    $values[] = self::CODE_B_IN_C;
                    $subset = 'B';
                }
            }
        }

        $values[] = self::checksum($values);
        $values[] = self::STOP;

        return $values;
    }

    /**
     * Weighted modulo-103 checksum over start + data symbol values.
     *
     * @param list<int> $values Start symbol followed by data symbols.
     */
    public static function checksum(array $values): int
    {
        $sum = $values[0];
        $count = count($values);
        for ($i = 1; $i < $count; $i++) {
            $sum += $values[$i] * $i;
        }
        return $sum % 103;
    }

    /**
     * Render symbol values as a '0'/'1' module pattern.
     *
     * @param list<int> $values
     */
    public static function patternFromValues(array $values): string
    {
        $pattern = '';
        foreach ($values as $value) {
            if (!isset(self::WIDTHES[$value])) {
                throw new \InvalidArgumentException(sprintf('Unknown Code 128 value: %s', $value));
            }
            $widths = self::WIDTHES[$value];
            $is_bar = true;
            $len = strlen($widths);
            for ($i = 0; $i < $len; $i++) {
                $pattern .= str_repeat($is_bar ? '1' : '0', (int) $widths[$i]);
                $is_bar = !$is_bar;
            }
        }
        return $pattern;
    }

    /**
     * Split a module pattern back into symbol values (for tests).
     *
     * @return list<int>
     */
    public static function valuesFromPattern(string $pattern): array
    {
        // Map "10100011000"-style patterns to values once.
        static $reverse = null;
        if ($reverse === null) {
            $reverse = [];
            foreach (self::WIDTHES as $value => $widths) {
                $reverse[self::widthsToPattern($widths)] = $value;
            }
        }

        $values = [];
        $length = strlen($pattern);
        $pos = 0;
        while ($pos < $length) {
            $rest = $length - $pos;
            // Every symbol except the stop one is 11 modules; the stop is 13.
            $take = $rest >= 13 && substr($pattern, $pos, 13) === self::widthsToPattern(self::WIDTHES[self::STOP])
                ? 13
                : 11;
            if ($take === 13 && $rest < 13) {
                throw new \InvalidArgumentException('Truncated barcode pattern.');
            }
            $chunk = substr($pattern, $pos, $take);
            if (!isset($reverse[$chunk])) {
                throw new \InvalidArgumentException(sprintf('Unknown symbol pattern "%s".', $chunk));
            }
            $values[] = $reverse[$chunk];
            $pos += $take;
        }
        return $values;
    }

    /**
     * Decode symbol values back to the encoded text (for tests).
     *
     * @param list<int> $values
     */
    public static function decodeValues(array $values): string
    {
        if (count($values) < 3) {
            throw new \InvalidArgumentException('Barcode too short.');
        }
        $stop = array_pop($values);
        if ($stop !== self::STOP) {
            throw new \InvalidArgumentException('Barcode does not end with the stop symbol.');
        }
        $expected = array_pop($values);
        if (self::checksum($values) !== $expected) {
            throw new \InvalidArgumentException('Checksum mismatch.');
        }

        $subset = array_shift($values);
        $text = '';
        foreach ($values as $value) {
            switch ($subset) {
                case self::START_A:
                    if ($value === 99) {
                        $subset = self::START_C;
                    } elseif ($value === self::CODE_B_IN_A) {
                        $subset = self::START_B;
                    } elseif ($value < 64) {
                        $text .= chr($value + 64);
                    } else {
                        $text .= chr($value + 32);
                    }
                    break;
                case self::START_B:
                    if ($value === self::CODE_C_IN_AB) {
                        $subset = self::START_C;
                    } elseif ($value === self::CODE_A_IN_B) {
                        $subset = self::START_A;
                    } else {
                        $text .= chr($value + 32);
                    }
                    break;
                case self::START_C:
                    if ($value === self::CODE_B_IN_C) {
                        $subset = self::START_B;
                    } elseif ($value === self::CODE_A_IN_C) {
                        $subset = self::START_A;
                    } elseif ($value >= 100) {
                        // FNC symbols are not produced by this encoder.
                        break;
                    } else {
                        $text .= sprintf('%02d', $value);
                    }
                    break;
                default:
                    throw new \InvalidArgumentException('Unexpected subset symbol.');
            }
        }
        return $text;
    }

    /**
     * Encode text to an inline SVG barcode image.
     *
     * The SVG scales horizontally to the container width (uniform module
     * scaling), so it can be stretched to the exact label width.
     *
     * @param string $text       Text to encode.
     * @param float  $height_mmm Barcode height in millimetres.
     * @param string $aria_label Accessible label (defaults to the text).
     * @throws \InvalidArgumentException
     */
    public static function toSvg(string $text, float $height_mmm = 11.0, string $aria_label = ''): string
    {
        $values = self::encode($text);
        $pattern = str_repeat('0', self::QUIET_ZONE)
            . self::patternFromValues($values)
            . str_repeat('0', self::QUIET_ZONE);

        // Build one <rect> per run of bars.
        $rects = '';
        $length = strlen($pattern);
        $pos = 0;
        while ($pos < $length) {
            $run_char = $pattern[$pos];
            $run_start = $pos;
            while ($pos < $length && $pattern[$pos] === $run_char) {
                $pos++;
            }
            if ($run_char === '1') {
                $rects .= sprintf(
                    '<rect x="%d" y="0" width="%d" height="100"/>',
                    $run_start,
                    $pos - $run_start,
                );
            }
        }

        if ($aria_label === '') {
            $aria_label = $text;
        }

        return sprintf(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d 100" preserveAspectRatio="none"'
            . ' style="display:block;width:100%%;height:%smm" role="img" aria-label="%s">'
            . '<rect x="0" y="0" width="%d" height="100" fill="#fff"/>'
            . '<g fill="#000">%s</g>'
            . '</svg>',
            $length,
            rtrim(rtrim(sprintf('%.2f', $height_mmm), '0'), '.'),
            htmlspecialchars($aria_label, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
            $length,
            $rects,
        );
    }

    /**
     * Dynamic programming over positions: minimal number of symbols to
     * encode text[pos..end] starting from the given subset.
     *
     * @return array{0: array<int, int>, 1: array<int, int>} dpB and dpC tables.
     */
    private static function plan(string $text): array
    {
        $length = strlen($text);

        $dpB = array_fill(0, $length + 1, PHP_INT_MAX);
        $dpC = array_fill(0, $length + 1, PHP_INT_MAX);
        $dpB[$length] = 0;
        $dpC[$length] = 0;

        for ($pos = $length - 1; $pos >= 0; $pos--) {
            $two_digits = $pos + 1 < $length
                && self::isDigit($text[$pos])
                && self::isDigit($text[$pos + 1]);

            // Subset B: encode one character, or switch to C before a digit pair.
            $dpB[$pos] = 1 + $dpB[$pos + 1];
            if ($two_digits && $dpC[$pos + 2] !== PHP_INT_MAX) {
                $dpB[$pos] = min($dpB[$pos], 1 + $dpC[$pos + 2]);
            }

            // Subset C: encode a digit pair, or switch back to B.
            if ($two_digits) {
                $dpC[$pos] = min(1 + $dpC[$pos + 2], 1 + $dpB[$pos + 1]);
            } else {
                $dpC[$pos] = 1 + $dpB[$pos];
            }
        }

        return [$dpB, $dpC];
    }

    private static function isDigit(string $char): bool
    {
        return $char >= '0' && $char <= '9';
    }

    private static function widthsToPattern(string $widths): string
    {
        $pattern = '';
        $is_bar = true;
        $len = strlen($widths);
        for ($i = 0; $i < $len; $i++) {
            $pattern .= str_repeat($is_bar ? '1' : '0', (int) $widths[$i]);
            $is_bar = !$is_bar;
        }
        return $pattern;
    }
}
