<?php

/**
 * ---------------------------------------------------------------------
 *
 * Labelprint - GLPI plugin printing 43x25 mm inventory labels.
 *
 * ---------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

namespace GlpiPlugin\Labelprint\Controller;

use CommonDBTM;
use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use GlpiPlugin\Labelprint\LabelRenderer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/**
 * Standalone label page: /plugins/labelprint/label?itemtype=Computer&id=42
 *
 * Opens in a new browser tab and triggers the print dialog on load.
 */
final class LabelController extends AbstractController
{
    #[SecurityStrategy(Firewall::STRATEGY_AUTHENTICATED)]
    #[Route('/label', name: 'label', methods: ['GET'])]
    public function __invoke(Request $request): Response
    {
        $itemtype = (string) $request->query->get('itemtype', '');
        $id       = (int) $request->query->get('id', 0);
        $copies   = (int) $request->query->get('copies', 1);

        if ($itemtype === '' || $id <= 0 || !class_exists($itemtype) || !is_subclass_of($itemtype, CommonDBTM::class)) {
            return $this->errorResponse('Некорректные параметры этикетки.');
        }

        /** @var CommonDBTM $item */
        $item = new $itemtype();

        if (!$item->isField('otherserial')) {
            return $this->errorResponse('У этого типа элементов нет инвентарного номера.');
        }
        if (!$item->getFromDB($id)) {
            return $this->errorResponse('Элемент не найден.');
        }
        if (!$item->can($id, READ)) {
            return $this->errorResponse('Нет прав на просмотр этого элемента.');
        }

        $inventory_number = trim((string) $item->fields['otherserial']);
        if ($inventory_number === '') {
            return $this->errorResponse('У элемента не заполнен инвентарный номер (поле «Инвентарный номер»).');
        }

        $title = trim((string) ($item->fields['name'] ?? ''));

        // Show entity name when the item is assigned to one.
        $comment = null;
        if ($item->isEntityAssign() && $item->isField('entities_id') && (int) $item->fields['entities_id'] > 0) {
            $entity = new \Entity();
            if ($entity->getFromDB((int) $item->fields['entities_id'])) {
                $entity_name = trim(\Toolbox::stripTags($entity->getFriendlyName()));
                $comment = $entity_name !== '' ? $entity_name : null;
            }
        }

        try {
            $html = (new LabelRenderer())->render($title, $inventory_number, $copies, $comment);
        } catch (\InvalidArgumentException $e) {
            return $this->errorResponse(
                'Не удалось сформировать штрихкод: ' . $e->getMessage()
            );
        }

        return new Response($html, headers: ['Content-Type' => 'text/html; charset=utf-8']);
    }

    private function errorResponse(string $message): Response
    {
        $esc = static fn(string $v): string => htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        $html = '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">'
            . '<title>Ошибка этикетки</title>'
            . '<style>
                body { font-family: "Segoe UI", Arial, sans-serif; padding: 24px; color: #333; }
                .box { max-width: 480px; margin: 40px auto; border: 1px solid #e0b4b4;
                       background: #fff6f6; border-radius: 6px; padding: 16px 20px; }
                h1 { font-size: 18px; margin: 0 0 8px; }
                p { margin: 0 0 12px; line-height: 1.4; }
                button { font: inherit; padding: 6px 14px; cursor: pointer; }
              </style></head><body>'
            . '<div class="box"><h1>Печать этикетки</h1>'
            . '<p>' . $esc($message) . '</p>'
            . '<button type="button" onclick="history.back()">Назад</button> '
            . '<button type="button" onclick="window.close()">Закрыть</button>'
            . '</div></body></html>';

        return new Response($html, status: 400, headers: ['Content-Type' => 'text/html; charset=utf-8']);
    }
}
