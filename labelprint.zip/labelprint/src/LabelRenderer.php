<?php

/**
 * ---------------------------------------------------------------------
 *
 * Labelprint - GLPI plugin printing 43x25 mm inventory labels.
 *
 * ---------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

namespace GlpiPlugin\Labelprint;

/**
 * Renders a complete standalone HTML page sized to a 43x25 mm label,
 * ready for the browser print dialog (thermal printer support).
 */
final class LabelRenderer
{
    public const LABEL_WIDTH_MM  = 43;
    public const LABEL_HEIGHT_MM = 25;

    /** Maximum printable copies per page. */
    public const MAX_COPIES = 100;

    /**
     * Build the label page.
     *
     * @param string      $title            Small line above the barcode (item name).
     * @param string      $inventory_number Inventory number below the barcode.
     * @param int         $copies           Number of label copies to print.
     * @param string|null $comment          Optional small line (e.g. entity name).
     * @return string Full HTML document.
     * @throws \InvalidArgumentException When the number cannot be encoded.
     */
    public function render(string $title, string $inventory_number, int $copies = 1, ?string $comment = null): string
    {
        $copies = max(1, min(self::MAX_COPIES, $copies));

        $esc = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        // Fail early (and loudly for the caller) if the number is not encodable.
        $barcode_svg = Barcode::toSvg($inventory_number, 11.0);

        $escaped_title   = $esc($title);
        $escaped_number  = $esc($inventory_number);
        $escaped_comment = $comment !== null ? $esc($comment) : null;
        $page_title      = $esc('Этикетка ' . $inventory_number);
        $print_label     = $esc('Печать');
        $close_label     = $esc('Закрыть');
        $width_mm        = self::LABEL_WIDTH_MM;
        $height_mm       = self::LABEL_HEIGHT_MM;

        $labels = '';
        for ($i = 0; $i < $copies; $i++) {
            $labels .= $this->renderLabel($escaped_title, $escaped_number, $barcode_svg, $escaped_comment);
        }

        $css = $this->renderCss($width_mm, $height_mm);

        return '<!DOCTYPE html>'
            . '<html lang="ru"><head><meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width, initial-scale=1">'
            . '<title>' . $page_title . '</title>'
            . '<style>' . $css . '</style></head><body>'
            . $labels
            . '<div class="toolbar">'
            . '<button type="button" class="primary" onclick="window.print()">' . $print_label . '</button>'
            . '<button type="button" onclick="window.close()">' . $close_label . '</button>'
            . '</div>'
            . '<script>window.addEventListener("load", function () {'
            . ' setTimeout(function () { window.print(); }, 200); });</script>'
            . '</body></html>';
    }

    private function renderCss(int $width_mm, int $height_mm): string
    {
        return <<<CSS
@page { size: {$width_mm}mm {$height_mm}mm; margin: 0; }

html, body {
    margin: 0;
    padding: 0;
    background: #fff;
    color: #000;
    font-family: "Segoe UI", Arial, Helvetica, sans-serif;
}

.label {
    box-sizing: border-box;
    width: {$width_mm}mm;
    height: {$height_mm}mm;
    padding: 1.2mm 1.5mm 1mm;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 0.4mm;
    overflow: hidden;
    text-align: center;
    page-break-after: always;
    break-after: page;
}

.label__title {
    max-width: 100%;
    font-size: 6pt;
    line-height: 1.1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.label__comment {
    max-width: 100%;
    font-size: 5pt;
    line-height: 1;
    color: #444;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.label__barcode {
    width: 100%;
    line-height: 0;
}

.label__number {
    max-width: 100%;
    font-size: 11pt;
    font-weight: 700;
    letter-spacing: 0.06em;
    line-height: 1.1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* On-screen toolbar, never printed. */
.toolbar {
    position: fixed;
    right: 16px;
    bottom: 16px;
    display: flex;
    gap: 8px;
    padding: 8px;
    background: #fff;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, .25);
    z-index: 100;
}
.toolbar button {
    font: inherit;
    font-size: 14px;
    padding: 6px 14px;
    cursor: pointer;
    border: 1px solid #888;
    border-radius: 4px;
    background: #f5f5f5;
}
.toolbar button.primary {
    background: #2b6cb0;
    border-color: #2b6cb0;
    color: #fff;
}

@media print {
    .toolbar { display: none !important; }
    .label:last-of-type { page-break-after: auto; break-after: auto; }
}
CSS;
    }

    private function renderLabel(string $escaped_title, string $escaped_number, string $barcode_svg, ?string $escaped_comment): string
    {
        $comment_html = $escaped_comment !== null && $escaped_comment !== ''
            ? '<div class="label__comment">' . $escaped_comment . '</div>'
            : '';

        return '<div class="label">'
            . '<div class="label__title">' . $escaped_title . '</div>'
            . $comment_html
            . '<div class="label__barcode">' . $barcode_svg . '</div>'
            . '<div class="label__number">' . $escaped_number . '</div>'
            . '</div>';
    }
}
