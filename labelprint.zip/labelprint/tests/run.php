<?php

/**
 * Standalone tests for the labelprint barcode logic.
 *
 * Run: php tests/run.php
 */

declare(strict_types=1);

require __DIR__ . '/../src/Barcode.php';

use GlpiPlugin\Labelprint\Barcode;

$failures = 0;
$checks   = 0;

function check(bool $condition, string $label): void
{
    global $failures, $checks;
    $checks++;
    if ($condition) {
        echo "  ok  - $label\n";
    } else {
        $failures++;
        echo "  FAIL - $label\n";
    }
}

// ---------------------------------------------------------------------------
// 1. Width table integrity
// ---------------------------------------------------------------------------
echo "Width table:\n";

$table = Barcode::widthTable();
check(count($table) === 107, 'table has 107 entries (0..106)');

$sums_ok      = true;
$digits_ok    = true;
$even_bars_ok = true;
foreach ($table as $value => $widths) {
    $sum = array_sum(array_map('intval', str_split($widths)));
    $expected_sum = $value === 106 ? 13 : 11;
    if ($sum !== $expected_sum) {
        $sums_ok = false;
        echo "       value $value (\"$widths\") sums to $sum, expected $expected_sum\n";
    }
    if (!preg_match('/^[1-4]+$/', $widths)) {
        $digits_ok = false;
    }
    // Bars are the odd positions (1st, 3rd, 5th...): their sum must be even,
    // spaces' sum must be odd (spec).
    $parts = str_split($widths);
    $bars = 0;
    $spaces = 0;
    foreach ($parts as $i => $w) {
        if ($i % 2 === 0) {
            $bars += (int) $w;
        } else {
            $spaces += (int) $w;
        }
    }
    if (($bars % 2) !== 0 || ($spaces % 2) !== 1) {
        $even_bars_ok = false;
        echo "       value $value: bars=$bars spaces=$spaces (parity wrong)\n";
    }
}
check($sums_ok, 'all symbols sum to 11 modules (stop: 13)');
check($digits_ok, 'all widths are single digits 1..4');
check($even_bars_ok, 'bar sums even, space sums odd');

$widths_only = array_values($table);
check(count($widths_only) === count(array_unique($widths_only)), 'all width patterns are unique');

check($table[103] === '211412', 'Start A = 211412');
check($table[104] === '211214', 'Start B = 211214');
check($table[105] === '211232', 'Start C = 211232');
check($table[106] === '2331112', 'Stop = 2331112');

// Known pattern from the spec: value 48 (P in code B) is "10100011000"? No —
// 'P' is value 48; Wikipedia lists P as 11101110110. Verify via pattern.
$pattern_of_48 = '';
$w = $table[48];
$is_bar = true;
foreach (str_split($w) as $width) {
    $pattern_of_48 .= str_repeat($is_bar ? '1' : '0', (int) $width);
    $is_bar = !$is_bar;
}
check($pattern_of_48 === '11101110110', 'value 48 (P) encodes to 11101110110 (spec example)');

// ---------------------------------------------------------------------------
// 2. Checksum: Wikipedia worked example "PJJ123C", start A => 54
// ---------------------------------------------------------------------------
echo "Checksum:\n";

// Start A + P(48) J(42) J(42) 1(17) 2(18) 3(19) C(35)
$pjj_values = [103, 48, 42, 42, 17, 18, 19, 35];
check(Barcode::checksum($pjj_values) === 54, 'PJJ123C (start A) checksum = 54 (Wikipedia example)');

// ---------------------------------------------------------------------------
// 3. Encode / decode round-trips
// ---------------------------------------------------------------------------
echo "Round-trips:\n";

$roundtrip_cases = [
    'INV-00012345',
    'PJJ123C',
    '12345678',
    '12345',
    'A1B2',
    'PC-2024/0007',
    'notebook-01',
    'СМЕТА-1',          // must be rejected, see below
    'X',
    '00',
    '0',
    str_repeat('9', 40),
    'GLPI-ASSET-000991',
    '  spaced  ',
];

foreach ($roundtrip_cases as $text) {
    try {
        $values = Barcode::encode($text);
    } catch (InvalidArgumentException $e) {
        // Only the non-ASCII case may fail.
        check($text === 'СМЕТА-1', "non-ASCII \"$text\" is rejected");
        continue;
    }

    $decoded = Barcode::decodeValues($values);
    check($decoded === $text, "round-trip \"$text\"");

    // Pattern round-trip: values -> pattern -> values
    $pattern = Barcode::patternFromValues($values);
    $back    = Barcode::valuesFromPattern($pattern);
    check($back === $values, "pattern round-trip \"$text\" (". strlen($pattern) . " modules)");

    check(end($values) === Barcode::STOP, "ends with stop \"$text\"");
    check($values[0] === Barcode::START_B || $values[0] === Barcode::START_C, "starts with B or C \"$text\"");

    // Checksum verification
    $check_value = $values[count($values) - 2];
    $body = array_slice($values, 0, -2);
    check(Barcode::checksum($body) === $check_value, "checksum consistent \"$text\"");
}

// ---------------------------------------------------------------------------
// 4. Subset optimization: long digit runs must use code C
// ---------------------------------------------------------------------------
echo "Subset selection:\n";

$v = Barcode::encode('12345678');
check($v[0] === Barcode::START_C, 'all-digits starts with code C');
// Start C + 4 pairs + check + stop = 7 symbols
check(count($v) === 7, '8 digits encode into 7 symbols (1 start + 4 pairs + check + stop)');

$v = Barcode::encode('ABC123456789012DEF');
check($v[0] === Barcode::START_B, 'mixed text starts with code B');
check(in_array(Barcode::START_C, $v, true) || in_array(99, $v, true), 'mixed text switches to C for the digit run');
$decoded = Barcode::decodeValues($v);
check($decoded === 'ABC123456789012DEF', 'mixed text round-trip');

// Odd-length digit run inside text: must still round-trip
$v = Barcode::encode('A12345B');
check(Barcode::decodeValues($v) === 'A12345B', 'odd digit run round-trip');

// ---------------------------------------------------------------------------
// 5. SVG rendering
// ---------------------------------------------------------------------------
echo "SVG:\n";

$svg = Barcode::toSvg('INV-00012345', 11.0);
check(str_starts_with($svg, '<svg'), 'svg output starts with <svg');
check(str_contains($svg, 'viewBox="0 0'), 'svg has viewBox');
check(str_contains($svg, 'height="100"'), 'svg bars are full height');
check(str_contains($svg, 'aria-label="INV-00012345"'), 'svg carries aria-label');
check(str_contains($svg, '<rect'), 'svg contains bar rects');

// Quiet zone: first bar must start at x >= 10 (background white rect excluded)
preg_match('/<g fill="#000"><rect x="(\d+)"/', $svg, $m);
check(($m[1] ?? 0) >= 10, 'left quiet zone >= 10 modules (first bar at x=' . ($m[1] ?? '?') . ')');

// Escaping: quotes and angle brackets in aria label
$svg2 = Barcode::toSvg('INV-00012345', 11.0, 'a"b<c>');
check(str_contains($svg2, 'aria-label="a&quot;b&lt;c&gt;"'), 'aria-label is escaped');

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------
echo "\n$checks checks, $failures failures\n";
exit($failures === 0 ? 0 : 1);
