<?php

/**
 * Generates a local preview of the label page for visual inspection.
 *
 * Run: php tests/preview.php [output-path]
 */

declare(strict_types=1);

require __DIR__ . '/../src/Barcode.php';
require __DIR__ . '/../src/LabelRenderer.php';

use GlpiPlugin\Labelprint\LabelRenderer;

$out = $argv[1] ?? (__DIR__ . '/preview.html');

$html = (new LabelRenderer())->render(
    'Lenovo ThinkCentre M70q',
    'INV-00012345',
    1,
    'Главный офис / ИТ-отдел',
);

file_put_contents($out, $html);
echo "written: $out\n";
