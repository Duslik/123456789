<?php

/**
 * ---------------------------------------------------------------------
 *
 * Labelprint - GLPI plugin printing 43x25 mm inventory labels.
 *
 * ---------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

use GlpiPlugin\Labelprint\LabelRenderer;

function plugin_labelprint_check_prerequisites(): bool
{
    if (version_compare(GLPI_VERSION, '11.0.0', '<')) {
        echo 'This plugin requires GLPI >= 11.0.0';
        return false;
    }
    return true;
}

function plugin_labelprint_check_config(): bool
{
    return true;
}

function plugin_labelprint_install(): bool
{
    return true;
}

function plugin_labelprint_uninstall(): bool
{
    return true;
}

/**
 * Build the label page URL for the given item.
 */
function plugin_labelprint_label_url(string $itemtype, int $id): string
{
    global $CFG_GLPI;

    return rtrim($CFG_GLPI['root_doc'] ?? '', '/')
        . '/plugins/labelprint/label?itemtype=' . rawurlencode($itemtype)
        . '&id=' . $id;
}

/**
 * "Print label" button on item forms (post_item_form hook).
 *
 * Must echo its output: the Twig extension discards hook return values.
 *
 * @param array{item?: object, options?: array<string, mixed>} $params
 */
function plugin_labelprint_post_item_form(array $params): void
{
    $item = $params['item'] ?? null;
    if (!$item instanceof CommonDBTM) {
        return;
    }

    $options = $params['options'] ?? [];

    // Only for real items opened in a full form (not new items, not modals).
    $id = (int) ($item->fields['id'] ?? 0);
    if ($id <= 0) {
        return;
    }
    if (!empty($options['in_modal'])) {
        return;
    }

    // Only item types carrying an inventory number field.
    if (!$item->isField('otherserial')) {
        return;
    }
    // Device components (CPU, memory, ...) share their parent's form.
    if ($item instanceof Item_Devices) {
        return;
    }

    // Skip deleted items and items the user cannot read.
    if (!empty($item->fields['is_deleted'])) {
        return;
    }
    if (!$item->can($id, READ)) {
        return;
    }

    $url = plugin_labelprint_label_url($item::class, $id);

    printf(
        '<div class="d-flex flex-row flex-wrap px-2 pb-2">'
        . '<a class="btn btn-outline-secondary" href="%s" target="_blank" rel="noopener" title="%s">'
        . '<i class="ti ti-printer"></i><span>%s</span></a></div>',
        htmlspecialchars($url, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        htmlspecialchars('Печать этикетки 43×25 мм', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        htmlspecialchars('Печать этикетки', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
    );
}
