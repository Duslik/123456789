<?php

/**
 * ---------------------------------------------------------------------
 *
 * Labelprint - GLPI plugin printing 43x25 mm inventory labels.
 *
 * ---------------------------------------------------------------------
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

/**
 * Plugin version descriptor, used by GLPI plugin manager.
 *
 * @return array<string, mixed>
 */
function plugin_version_labelprint(): array
{
    return [
        'name'     => 'Labelprint',
        'version'  => '1.0.0',
        'author'   => 'IT Department',
        'license'  => 'GPL-3.0-or-later',
        'homepage' => '',
        'requirements' => [
            'glpi' => [
                'min' => '11.0',
                'max' => '11.99.99',
            ],
        ],
    ];
}

/**
 * Plugin initialisation: register hooks.
 */
function plugin_init_labelprint(): void
{
    global $PLUGIN_HOOKS;

    // Directly registered callable (array params are passed as-is by Plugin::doHook()).
    // The callback prints its output itself, Twig discards hook return values.
    $PLUGIN_HOOKS['post_item_form']['labelprint'] = 'plugin_labelprint_post_item_form';
}
